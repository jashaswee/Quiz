import React, { useState } from 'react'
import './Quiz.css'
import Questions from './Questions.jsx'

function Quiz ()
{
    // Single state object for all form values
    const [ question_Query, setQuestion_Query ] = useState( {
        amount: 10,
        category: 'any',
        difficulty: 'any',
        type: 'any',
        encode: 'default'
    } )
    // State to toggle between form and Questions component
    const [ showQuestions, setShowQuestions ] = useState( false )

    // Handler to update state on input change
    const handleChange = ( e ) =>
    {
        const { name, value } = e.target
        setQuestion_Query( prev => ( { ...prev, [ name ]: value } ) )
    }
    // Handler for form submission
    const handleSubmit = ( e ) =>
    {
        e.preventDefault()
        setShowQuestions( true ) // Show Questions component with the query
    }
    return (
        <>
            { !showQuestions ? (
                < div className="py-4" >
                    <div className="container">
                        <h1 className="text-start mb-4 quiz-header">Check Your Knowledge</h1>
                        <div className="container bg-light p-4 rounded shadow-sm">
                            <h2 className="text-primary mb-3">Quiz Master</h2>
                            <p className="text-muted mb-4">Welcome to Quiz Master! Customize your quiz by selecting the number of questions, category, difficulty, type, and encoding. Click 'Generate Questions' to start.</p>
                            <form onSubmit={ handleSubmit } className="form-api">
                                <div className="mb-3">
                                    <label htmlFor="amount" className="form-label">Number of Questions:</label>
                                    <input type="number" name="amount" id="amount" className="form-control"
                                        min="1" max="50"
                                        value={ question_Query.amount }
                                        onChange={ handleChange } />
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="category" className="form-label">Select Category:</label>
                                    <select name="category" className="form-control"
                                        value={ question_Query.category }
                                        onChange={ handleChange }>
                                        <option value="any">Any Category</option>
                                        <option value="9">General Knowledge</option>
                                        <option value="10">Entertainment: Books</option>
                                        <option value="11">Entertainment: Film</option>
                                        <option value="12">Entertainment: Music</option>
                                        <option value="13">Entertainment: Musicals &amp; Theatres</option>
                                        <option value="14">Entertainment: Television</option>
                                        <option value="15">Entertainment: Video Games</option>
                                        <option value="16">Entertainment: Board Games</option>
                                        <option value="17">Science &amp; Nature</option>
                                        <option value="18">Science: Computers</option>
                                        <option value="19">Science: Mathematics</option>
                                        <option value="20">Mythology</option>
                                        <option value="21">Sports</option>
                                        <option value="22">Geography</option>
                                        <option value="23">History</option>
                                        <option value="24">Politics</option>
                                        <option value="25">Art</option>
                                        <option value="26">Celebrities</option>
                                        <option value="27">Animals</option>
                                        <option value="28">Vehicles</option>
                                        <option value="29">Entertainment: Comics</option>
                                        <option value="30">Science: Gadgets</option>
                                        <option value="31">Entertainment: Japanese Anime &amp; Manga</option>
                                        <option value="32">Entertainment: Cartoon &amp; Animations</option>
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="difficulty" className="form-label">Select Difficulty:</label>
                                    <select name="difficulty" className="form-control"
                                        value={ question_Query.difficulty }
                                        onChange={ handleChange }>
                                        <option value="any">Any Difficulty</option>
                                        <option value="easy">Easy</option>
                                        <option value="medium">Medium</option>
                                        <option value="hard">Hard</option>
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="type" className="form-label">Select Type:</label>
                                    <select name="type" className="form-control"
                                        value={ question_Query.type }
                                        onChange={ handleChange }>
                                        <option value="any">Any Type</option>
                                        <option value="multiple">Multiple Choice</option>
                                        <option value="boolean">True / False</option>
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label htmlFor="encode" className="form-label">Select Encoding:</label>
                                    <select name="encode" className="form-control"
                                        value={ question_Query.encode }
                                        onChange={ handleChange }>
                                        <option value="default">Default Encoding</option>
                                        <option value="urlLegacy">Legacy URL Encoding</option>
                                        <option value="url3986">URL Encoding (RFC 3986)</option>
                                        <option value="base64">Base64 Encoding</option>
                                    </select>
                                </div>
                                <div className="d-grid">
                                    <button className="btn btn-lg btn-primary" type="submit">Generate Questions</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div >
            ) : (

                <Questions question_Query={ question_Query } onBack={ () => setShowQuestions( false ) } />
            )
            }
        </>
    )
}

export default Quiz