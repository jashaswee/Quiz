import React from 'react'


function Result ( { show, onClose, quizData, selectedAnswers } )
{
    if ( !show ) return null

    // Calculate score
    const totalQuestions = quizData.length
    let correctCount = 0
    const results = quizData.map( ( question, index ) =>
    {
        const selected = selectedAnswers.find( ans => ans.index === index )
        const isCorrect = selected && selected.selectedAnswer.toLowerCase() === question.correct_answer.toLowerCase()
        if ( isCorrect )
        {
            correctCount++
        }
        return {
            question: question.question,
            correctAnswer: question.correct_answer,
            selectedAnswer: selected ? selected.selectedAnswer : 'Not answered'
        }
    } )

    return (
        <div className="modal fade show d-block" tabIndex="-1" style={ { backgroundColor: 'rgba(0,0,0,0.5)' } }>
            <div className="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
                <div className="modal-content">
                    <div className="modal-header">
                        <h5 className="modal-title">Quiz Results</h5>
                        <button type="button" className="btn-close" onClick={ onClose }></button>
                    </div>
                    <div className="modal-body">
                        <h3 className="text-center mb-4">Your Score: { correctCount }/{ totalQuestions }</h3>

                        <div className="table-responsive">
                            <table className="table table-striped table-bordered">
                                <thead className="table-dark">
                                    <tr>
                                        <th>Question</th>
                                        <th>Correct Answer</th>
                                        <th>Your Answer</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    { results.map( ( result, index ) => (
                                        <tr key={ index }>
                                            <td dangerouslySetInnerHTML={ { __html: result.question } }></td>
                                            <td dangerouslySetInnerHTML={ { __html: result.correctAnswer } }></td>
                                            <td dangerouslySetInnerHTML={ { __html: result.selectedAnswer } }></td>
                                        </tr>
                                    ) ) }
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn btn-secondary" onClick={ onClose }>Close</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Result
