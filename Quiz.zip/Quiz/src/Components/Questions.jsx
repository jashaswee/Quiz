import React, { useState, useEffect } from 'react'
import axios from 'axios'
import DataTable from 'react-data-table-component'
import Result from './Result.jsx'

export default function Questions ( { question_Query, onBack } )
{
    const [ quizData, setQuizData ] = useState( [] )
    const [ loading, setLoading ] = useState( true )
    const [ error, setError ] = useState( null )
    const [ selectedAnswers, setSelectedAnswers ] = useState( [] )
    const [ showResultModal, setShowResultModal ] = useState( false )

    useEffect( () =>
    {
        setTimeout( () =>
        {
            let url = 'https://opentdb.com/api.php?'
            url += `amount=${ encodeURIComponent( question_Query.amount ) }`
            if ( question_Query.category !== 'any' ) url += `&category=${ question_Query.category }`
            if ( question_Query.difficulty !== 'any' ) url += `&difficulty=${ question_Query.difficulty }`
            if ( question_Query.type !== 'any' ) url += `&type=${ question_Query.type }`
            if ( question_Query.encode !== 'default' ) url += `&encode=${ question_Query.encode }`
            axios.get( url )
                .then( ( response ) =>
                {
                    if ( response.data.results )
                    {
                        setQuizData( response.data.results )
                    } else
                    {
                        setError( 'No questions found.' )
                    }
                    setLoading( false )
                } )
                .catch( () =>
                {
                    setError( 'Error fetching questions. Please try again.' )
                    setLoading( false )
                } )
        }, 1000 )
        // Construct the API URL by concatenating values from question_Query

    }, [ question_Query ] )

    // Handler for radio button selection
    const handleAnswerSelect = ( questionIndex, selectedAnswer, questionText ) =>
    {
        setSelectedAnswers( prev =>
        {
            const existingIndex = prev.findIndex( ( item ) => { return item.index === questionIndex } )
            const newRecord = { index: questionIndex, question: questionText, selectedAnswer: selectedAnswer }

            if ( existingIndex >= 0 )
            {
                // Replace if already selected for this question
                const updated = [ ...prev ]
                updated[ existingIndex ] = newRecord
                return updated
            } else
            {
                // Add new record
                return [ ...prev, newRecord ]
            }
        } )
        console.log( selectedAnswers )
    }
    const handleSubmitAnswers = () =>
    {
        setShowResultModal( true ) // Open the result modal
    }

    const handleCloseModal = () =>
    {
        setShowResultModal( false )
        onBack() // Go back to initial Quiz.jsx state
    }

    // Define DataTable columns
    const columns = [
        {
            name: 'Question',
            selector: ( row ) => { return row.question },
            sortable: true,
            cell: ( row ) => { return <div dangerouslySetInnerHTML={ { __html: row.question } }></div> },
        },
        {
            name: 'Answers',
            cell: ( row, index ) =>
            {
                const allAnswers = [ row.correct_answer, ...row.incorrect_answers ]
                return (
                    <div>
                        { allAnswers.map( ( answer, ansIndex ) => (
                            <div key={ ansIndex } className="form-check">
                                <input
                                    className="form-check-input"
                                    type="radio"
                                    name={ `question-${ index }` }
                                    id={ `question-${ index }-answer-${ ansIndex }` }
                                    value={ answer }
                                    onChange={ () => handleAnswerSelect( index, answer, row.question ) }
                                />
                                <label
                                    className="form-check-label"
                                    htmlFor={ `question-${ index }-answer-${ ansIndex }` }
                                    dangerouslySetInnerHTML={ { __html: answer } }
                                ></label>
                            </div>
                        ) ) }
                    </div>
                )
            },
        },
    ]

    if ( loading )
    {
        return <div><p className='text-bg-dark'>Loading questions...</p></div>
    }
    if ( error )
    {
        return (
            <div>
                <p>{ error }</p>
                <button onClick={ onBack } className="btn btn-secondary mt-3">Back to Quiz Setup</button>
            </div>
        )
    }
    return (
        <div className="py-4">
            <div className="container">
                <button className="btn btn-secondary mb-4" onClick={ onBack }>Back to Quiz Setup</button>
                <h2 className="text-primary mb-4">Generated Questions</h2>

                <DataTable
                    columns={ columns }
                    data={ quizData }
                    pagination
                    paginationPerPage={ 10 }
                    highlightOnHover
                    striped
                />

                <div className="mt-4">
                    <button className="btn btn-primary"
                        onClick={ handleSubmitAnswers }
                        disabled={ selectedAnswers.length < quizData.length }
                    >
                        Submit Answers
                    </button>
                </div>
                {/* Result Modal */ }
                <Result
                    show={ showResultModal }
                    onClose={ handleCloseModal }
                    quizData={ quizData }
                    selectedAnswers={ selectedAnswers }
                />
            </div>
        </div>
    )
}
