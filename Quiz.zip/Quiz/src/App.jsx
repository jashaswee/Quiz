
import './App.css'
import Quiz from './Components/Quiz.jsx'
function App ()
{

  return (
    <>
      <Quiz />
    </>
  )
}

export default App
